package org.yanglin.mr.lab.ecg;

public class PESCException extends Exception
{

	public PESCException()
	{
		// TODO Auto-generated constructor stub
	}

	public PESCException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PESCException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PESCException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
